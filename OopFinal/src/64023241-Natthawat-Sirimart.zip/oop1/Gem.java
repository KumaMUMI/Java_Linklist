package oop1;

public interface Gem {

	public String price();

	public String name();

	public String type();

	public String color();

}
