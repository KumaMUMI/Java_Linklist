package oop1;

public class Main {
	public static void main(String[] args) {

		Gem diamon = new Diamond();
		Gem ruby = new Ruby();
		Gem emerrald = new Emerald();

		System.out.println(diamon.name());
		System.out.println(diamon.type());
		System.out.println(diamon.color());
		System.out.println(diamon.price());

		System.out.println();

		System.out.println(ruby.name());
		System.out.println(ruby.type());
		System.out.println(ruby.color());
		System.out.println(ruby.price());

		System.out.println();

		System.out.println(emerrald.name());
		System.out.println(emerrald.type());
		System.out.println(emerrald.color());
		System.out.println(emerrald.price());
	}
}
