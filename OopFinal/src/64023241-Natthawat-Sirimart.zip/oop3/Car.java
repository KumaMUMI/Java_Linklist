package oop3;

public class Car {

	protected String fullName;
	protected int priceCar;

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public int getPriceCar() {
		return priceCar;
	}

	public void setPriceCar(int priceCar) {
		this.priceCar = priceCar;
	}

}
