package dev.chaow;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class LinkedList<E> {
	
	Node<E> head = null; // null = ��ҧ
	Node<E> tail = null;

	public LinkedList() {
		head = null;
		tail = null;
	}
	
	public void append(E data) {
		Node<E> node = new Node<E>(data, null); // new node
		
		if(head == null) {
			// insert first node
			head = node;
			tail = node;
		}else {
			tail.next = node;	//��� Node �ҵ�ͷ��������
			tail = node; // ��� tail �����������
		}
	}
	
	public void insert(E data, int index) {
		Node<E> node = new Node<E>(data,null);
		if (index == 0) {
			//�á˹���� 
			node.next = head;
			head =node;
			if(tail == null) {
				tail = head;
			}
		}else if(index > 0) {
			Node<E> pre = head;
			for(int i =0 ;i<index-1 && pre.next != null;i++) {
				pre = pre.next;
			}
			node.next = pre.next;
			pre.next = node;
			
			if(node.next == null) {
				tail = node;
			}
		}
	}
	
	public void remove(int index) {
		if (index == 0) {
			if(head != null) {
				head = head.next;	
			}
		}else if (index > 0 ) {
			Node<E> pre = head;
			for(int i =0 ;i<index-1 && pre.next != null;i++) {
				pre = pre.next;
			}
			if( pre.next == null) {
				//���˹�ź��������ش ���˹��Թ��͹
				
				
			}else {
				// ���˹�ź����ç��ҧ
				pre.next= pre.next.next; 
				if(pre.next == null) {
					tail = pre;
				}
			}
		}
	}
	
	
	public void show() {
		Node<E> p =  head;
		System.out.print("head -> ");
		while(p != null) {
			//find last node.
			System.out.print(p.data + " -> ");
			p = p.next;	
		}
		System.out.println("/");
	}
	
	//overload
	public void show(String msg) {
		System.out.print(msg + " : ");
		this.show();
	}
	
	public E get(int index) {
		Node<E> p = head;
		
		for(int i=0;i<index && p != null;i++) {
			p = p.next;
		}
		if( p == null) {
			return null;
		}else {
			return p.data;
		}
	}
	
	
	public void set(int index,E data) {
		Node<E> p = head;
		
		for(int i=0;i<index && p != null;i++) {
			p = p.next;
		}
		if( p == null) {
			// ���˹���
		}else {
			p.data = data;
		}
	}


}
