package dev.chaow.tree;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Tree root = new Tree(2);
		Tree firstChild = new Tree(7);
		Tree secondChild = new Tree(5);

		root.subTrees.add(firstChild);
		root.subTrees.add(secondChild);
		
		firstChild.subTrees.add(new Tree(2));
		firstChild.subTrees.add(new Tree(10));
		firstChild.subTrees.add(new Tree(6));
		
		firstChild.subTrees.get(2)
			.subTrees.add(new Tree(5));
		
		firstChild.subTrees.get(2)
			.subTrees.add(new Tree(11));
		
		secondChild.subTrees.add(new Tree(9));
		secondChild.subTrees.get(0)
			.subTrees.add(new Tree(4));
		
		
//		root.printTreeRecur(0);
		root.printBreathFirstSearch();
		
	}

}
