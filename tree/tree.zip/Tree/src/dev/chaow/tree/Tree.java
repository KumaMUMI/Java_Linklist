package dev.chaow.tree;

import java.util.ArrayList;
import java.util.List;

public class Tree {

	//�� Integer class ��������� null ��
	public Integer data = null; 
	public List<Tree> subTrees = null;
	
	public Tree(Integer data) {
		super();
		this.data = data;
		subTrees = new ArrayList<Tree>();
	}

	public void printTreeRecur(int level) {
		// TODO Auto-generated method stub
		for(int i = 0;i<level ;i++) {
			System.out.print(" ");
		}
		System.out.print("-");
		System.out.println(data);
		
		for (Tree tree : subTrees) {
			
			tree.printTreeRecur(level + 1);
		}
		
	}
	
	public void printBreathFirstSearch() {
		ArrayList<Tree> queue = new ArrayList<Tree>();
		queue.add(this);
		
		while (!queue.isEmpty()) {
			Tree p = queue.remove(0);
			for (Tree tree : p.subTrees) {
				queue.add(tree);
			}
			
			System.out.println(p.data);
		}
	}
}
